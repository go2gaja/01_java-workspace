package com.kh.practice1.func;

import java.util.Scanner;

public class VariablePractice2 {
	
	public void VariablePractice () {
						   
		        Scanner scanner = new Scanner(System.in);

		        System.out.print("첫 번째 정수 : ");
		        int num1 = scanner.nextInt();

		        System.out.print("두 번째 정수 : ");
		        int num2 = scanner.nextInt();

		        System.out.println("더하기 결과 : " + (num1 + num2));
		        System.out.println("빼기 결과 : " + (num1 - num2));
		        System.out.println("곱하기 결과 : " + (num1 * num2));
		        System.out.println("나누기 몫 결과 : " + (num1 / num2));
		        
		        scanner.close();
	    }

}
