package com.kh.practice1;

import com.kh.practice1.func.VariablePractice2;
import com.kh.practice1.func.VariablePractice3;
import com.kh.practice1.func.VariablePractice4;
import com.kh.practice1.func.VariablePractice1.VariablePractice1;

public class run {
	public static void main(String[] args) {
		VariablePractice1 a = new VariablePractice1 ();
		//a.VariablePractice();
		VariablePractice2 b = new VariablePractice2 ();
		//b.VariablePractice();
		VariablePractice3 c = new VariablePractice3 ();
		//c.VariablePractice();
		VariablePractice4 d = new VariablePractice4 ();
		d.VariablePractice();
		
		
		
		
	}

}
