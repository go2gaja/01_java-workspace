package com.kh.practice.func.Run;

import com.kh.practice.func.OperatorPractice.OperatorPractice;

public class Run {
	public static void main(String[]arg) {
		OperatorPractice a = new OperatorPractice ();
		
		//a.practice1();
		//a.practice2();
		//a.practice3();
		//a.practice4();
		//a.practice5();
		//a.practice6();
		//a.practice7();
		//a.practice8();
		//a.practice9();
		//a.practice10();
		a.practice11();
		
		
		
		
		
	}

}
