package com.kh.practice.chap01.ControlPractice;

public class run {
	public static void main(String[]arg) {

		ControlPractice a = new ControlPractice();
		
		//a.practice1();
		//a.practice2();
		//a.practice3();
		//a.practice4();
		//a.practice5();
		//a.practice6();
		//a.practice7();
		a.practice8();
	}
}
	
