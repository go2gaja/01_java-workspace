package com.kh.practice.array;

public class Run {
	public static void main (String[] arg) {
		
		A_ArrayPractice a = new A_ArrayPractice();
		
		//a.method1();
		//a.method2();
		//a.method3();
		//a.method4();
		//a.method5();
		//a.method6();
		//a.method7();
		//a.method8();
		a.method9();
		//a.method10();
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
	}

}
