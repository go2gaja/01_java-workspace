package com.kh.practice.Product;

public class run {

	public static void main(String[] args) {
		Product pro =new Product();
		
		Product product = new Product();
        product.setpName("삼성");
        product.setPrice(10000000);
        product.setBrand("Sam");

        System.out.println("상품명: " + product.getpName());
        System.out.println("가격: " + product.getPrice());
        System.out.println("브랜드: " + product.getBrand());
    }

		
	}


